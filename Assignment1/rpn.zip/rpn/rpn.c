#define N		(10)

int main(void)
{
	return 0;
}
